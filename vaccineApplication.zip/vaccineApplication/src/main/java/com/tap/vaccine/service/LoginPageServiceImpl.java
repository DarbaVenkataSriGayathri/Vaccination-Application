package com.tap.vaccine.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.tap.vaccine.dao.LoginDAO;
import com.tap.vaccine.entity.RegisterEntity;

@Component
public class LoginPageServiceImpl implements LoginService{
	
	private LoginDAO loginDAO;
	private EmailService emailService;
	

	@Autowired
	public LoginPageServiceImpl(LoginDAO loginDAO, EmailService emailService) {
		
		this.loginDAO = loginDAO;
		this.emailService = emailService;
	}
	
	private static final int MAX_LOGIN_ATTEMPTS = 3;
	String passwordRegex="^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$%*&?!])[a-zA-Z\\d@!?%*&]{8,}$";
	
	public LoginPageServiceImpl() {
		System.out.println("Default Constructor of Login Service");
	}

	@Override
	public boolean validateLoginCredentials(String email, String password) {
		
		 boolean isValid = true;

		    if (email == null || email.isEmpty() || !email.endsWith("@gmail.com")) {
		        isValid = false;
		        System.out.println("Email is invalid");
		    }

		    if (password == null || password.isEmpty() || !password.matches(passwordRegex)) {
		        isValid = false;
		        System.out.println("Password is invalid");
		    }

		    return isValid;
	}

	@Override
    public boolean verifyLoginCredentials(String email, String password) throws Exception{
		RegisterEntity registerEntity = loginDAO.getRegisterEntityByEmail(email);
		if(registerEntity==null) {
			
			throw new Exception("User Not Found");
			
		}

        if(email==null || email.isEmpty() ||  !email.endsWith("@gmail.com") || password == null || password.isEmpty() || !password.matches(passwordRegex)) 
        {
        	throw new Exception("Invalid credentials. Please enter valid email and password.");
        }

        if (registerEntity.getLoginAttempt() >= MAX_LOGIN_ATTEMPTS) {
            emailService.blockedEmail(registerEntity.getEmail());
            throw new Exception("Account locked due to too many login attempts. Please Reset Password");
        }
        if (password.equals(registerEntity.getPassword())) {
		    
		    registerEntity.setLoginAttempt(0);
		    loginDAO.updateRegisterEntity(registerEntity);

		    return true;
		}
        else {
        	registerEntity.setLoginAttempt(registerEntity.getLoginAttempt()+1);
			loginDAO.updateRegisterEntity(registerEntity);
			if(registerEntity.getLoginAttempt()>=MAX_LOGIN_ATTEMPTS)
			{
			    emailService.blockedEmail(registerEntity.getEmail());
			    throw new Exception("Account locked due to too many login attempts. Please Reset Password");
			}
			
			else {
				
				throw new Exception("Invalid Password" + (MAX_LOGIN_ATTEMPTS - registerEntity.getLoginAttempt()) +" attempts left");
			
			}
        	
        }      
   	}

		       
}
