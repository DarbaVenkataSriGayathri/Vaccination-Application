package com.tap.vaccine.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.tap.vaccine.entity.RegisterEntity;

@Component
public class LoginDAOImpl implements LoginDAO{
	
	private SessionFactory sessionFactory;
	private Session session;
	private Query query;
	
	@Autowired
	public LoginDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}


	@Override
	public RegisterEntity getRegisterEntityByEmail(String email) {
		RegisterEntity entity=null;
		session=null;
		String hql="from RegisterEntity where email= :email";
		try {
			
			session =sessionFactory.openSession();
			query = session.createQuery(hql, RegisterEntity.class);
			query.setParameter("email", email);
			entity = (RegisterEntity) query.uniqueResult();
			if(entity!=null) {
				System.out.println("Found RegisterEntity with Email "+email);
			}
			else {
				System.out.println("Not Found RegisterEntity with Email "+email);
			}
		}
		finally {
			
			if(session!=null) {
				session.close();
			}			
		}
		return entity;
	}


	@Override
	public boolean updateRegisterEntity(RegisterEntity registerEntity) {
		session=null;
		Transaction transaction=null;
		String hql="update RegisterEntity set loginAttempt = :loginAttempt where email = :email";
		
		try {
			
			session=sessionFactory.openSession();
			transaction = session.beginTransaction();
			query = session.createQuery(hql);
			query.setParameter("loginAttempt", registerEntity.getLoginAttempt());
			query.setParameter("email", registerEntity.getEmail());
			query.executeUpdate();
			transaction.commit();	
		}
		catch(Exception e) {
			if(transaction!=null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
		finally {
			if(session!=null) {
				session.close();
			}
		}
		return false;
	}
	
}
