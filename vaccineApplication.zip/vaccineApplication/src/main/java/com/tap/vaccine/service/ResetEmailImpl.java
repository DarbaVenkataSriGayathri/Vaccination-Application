package com.tap.vaccine.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Component;

@Component
public class ResetEmailImpl implements ResetEmail{
	
	private JavaMailSender javaMailSenderImpl;
	
	@Autowired
	public ResetEmailImpl(JavaMailSender javaMailSenderImpl) {
		
		this.javaMailSenderImpl = javaMailSenderImpl;
	}
	
	@Override
	public boolean sendResetEmail(String to, String newPassword) throws Exception {
		try {
			
			SimpleMailMessage simpleMailMessage=new SimpleMailMessage();
			
			simpleMailMessage.setTo(to);
			simpleMailMessage.setSubject("Password Reset Successful");
			simpleMailMessage.setText("Your password has been successfully reset. Your new password is: " + newPassword);
			javaMailSenderImpl.send(simpleMailMessage);
			System.out.println("Mail snet Successfully");
			
		}
		catch(MailException e) {
			e.printStackTrace();
			throw new Exception("Mail Failed to Send");
			
		}
		return true;
	}
	
}
