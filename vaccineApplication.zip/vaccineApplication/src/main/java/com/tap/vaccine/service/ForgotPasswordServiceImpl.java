package com.tap.vaccine.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.tap.vaccine.dao.ForgotPasswordDAO;
import com.tap.vaccine.entity.RegisterEntity;

@Service
public class ForgotPasswordServiceImpl implements ForgotPasswordService{
	
	private ForgotPasswordDAO forgotPassword;
	private ResetEmail resetEmail;
	
	@Autowired
	public ForgotPasswordServiceImpl(ForgotPasswordDAO forgotPassword, ResetEmail resetEmail) {
		this.forgotPassword = forgotPassword;
		this.resetEmail = resetEmail;
	}
	
	public ForgotPasswordServiceImpl() {
		System.out.println("ForgotPasswordServiceImpl...is executed");
	}

	@Override
	public boolean validateForgotPassword(String email, String newPassword, String confirmPassword) {
		String passwordRegex="^(?=.*[a-z])(?=.*[A-Z])(?=.*\\\\d)(?=.*[@$%*&?!])[a-zA-Z\\\\d@!?%*&]{8,}$";
		boolean isValid=true;

		 if (email == null || email.isEmpty() || !email.endsWith("@gmail.com")) 
		 {
		        isValid = false;
		        System.out.println("Email is invalid");
		 }
		 if (newPassword == null || newPassword.isEmpty() || !newPassword.matches(passwordRegex)) {
			 isValid = false;
		        System.out.println("Password is invalid");
		 }
		 return isValid;
	
	}
	
	@Override
	public boolean updateForgotPassword(String email, String newPassword) throws Exception{
		
		System.out.println(" updateForgotPassword registerEntity");
		
		RegisterEntity registerEntity = forgotPassword.getRegisterEntityByEmail(email);
		if(registerEntity!=null) {
			
			registerEntity.setPassword(newPassword);
			boolean updated = forgotPassword.updateForgotPassword(registerEntity);
			if(updated) {
				
				resetEmail.sendResetEmail(registerEntity.getEmail(), newPassword);
			}	
		}
		return false;
	}	
}
