package com.tap.vaccine.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.tap.vaccine.entity.RegisterEntity;

@Component
public class ForgotPasswordDAOImpl implements ForgotPasswordDAO{
	private SessionFactory sessionFactory;
	private Session session;
	private Query query;
	@Autowired
	public ForgotPasswordDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	@Override
	public RegisterEntity getRegisterEntityByEmail(String email) {
		RegisterEntity entity=null;
		session=null;
		String hql="from RegisterEntity where Email= :email";
		try {
			session = sessionFactory.openSession();
			query = session.createQuery(hql, RegisterEntity.class);
			query.setParameter("email", email);
			entity = (RegisterEntity) query.uniqueResult();	
			if(entity!=null) {
				
				System.out.println("Found RegisterEntity with Email "+email);
			}
			else {
				System.out.println("Not Found RegisterEntity with Email "+email);
			}
			
		}
		finally {
			if(session!=null) {
				session.close();
			}
		}
		return entity;
	}

	@Override
	public boolean updateForgotPassword(RegisterEntity registerEntity) {
		
		boolean isDataValid=false;
		Transaction transaction=null;
		session=null;
		try {
			
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			session.createQuery("UPDATE RegisterEntity SET loginAttempt=0 , password = :newPassword WHERE email = :email")
                    .setParameter("newPassword", registerEntity.getPassword())
                    .setParameter("email", registerEntity.getEmail()) 
                    .executeUpdate();
			transaction.commit();
			isDataValid=true;
		}
		catch(Exception e) {
			if(transaction!=null) {	
				transaction.rollback();
				System.out.println("transaction rollback");
			}
		}
		finally {
			
			if(session!=null) {
				System.out.println("session.close()");
				session.close();
				
			}
				
		}
		return isDataValid;
	}

	
}
