package com.tap.vaccine.service;

public interface RegisterService {
	
	boolean validateUserName(String userName);

	boolean validatePassword(String password);

	boolean validateConfirmPassword(String confirmPassword);

	boolean validateEmail(String email);

	boolean validateMobileNumber(String mobileNumber);

	boolean validateGender(String gender);
	
	boolean validateRegisterData(String userName, String password, String confirmPassword, String email,
			String mobileNumber, String gender, String dateOfBirth);

	boolean saveRegisterData(String userName, String password, String email, String mobileNumber, String gender,
			String dateOfBirth);

	boolean validateDateOfBirth(String dateOfBirth);
	

}
