package com.tap.vaccine.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import com.tap.vaccine.service.ForgotPasswordService;

@Controller
public class ForgotPasswordController {
	
	
	private ForgotPasswordService forgotPasswordService;
	

	@Autowired
	public ForgotPasswordController(ForgotPasswordService forgotPasswordService) {
		
		this.forgotPasswordService = forgotPasswordService;
	}
	
	public ForgotPasswordController() {
		System.out.println("ForgotPasswordController is an Default Constructor");
	}
	
	@RequestMapping(value="/forgotpassword")
	public String forgotPasswordPage() {
		
		return "/WEB-INF/forgotpassword.jsp";
	}
	
	
	
	@RequestMapping(value="/resetForgotPassword", method = RequestMethod.GET)
	public String resetForgotPassword(@RequestParam String email, @RequestParam String newPassword, @RequestParam String confirmPassword, Model model) throws Exception{
		
		try {
            if (!newPassword.equals(confirmPassword)) {
                throw new Exception("confirmPassword must be equal to newPassword");
            }

            boolean validateForgotPassword = forgotPasswordService.validateForgotPassword(email, newPassword, confirmPassword);
            if (validateForgotPassword) {
                boolean updated = forgotPasswordService.updateForgotPassword(email, newPassword);
                if (updated) {
                    model.addAttribute("response", "Password Reset Successfully");
                    return "/forgotpassword.jsp";
                } else {
                    throw new Exception("Failed to update password");
                }
            } else {
                throw new Exception("Invalid input for password reset");
            }
        } catch (Exception e) {
            model.addAttribute("response", e.getMessage());
            return "/WEB-INF/forgotpassword.jsp";
        }
    }
}