package com.tap.vaccine.service;


public interface ForgotPasswordService {
	
	
	boolean validateForgotPassword(String email, String newPassword, String confirmPassword);
	boolean updateForgotPassword(String email, String newPassword) throws Exception;
	

}
