package com.tap.vaccine.service;


public interface LoginService {
	
	boolean validateLoginCredentials(String email, String password);
	boolean verifyLoginCredentials(String email, String password) throws Exception;

}
