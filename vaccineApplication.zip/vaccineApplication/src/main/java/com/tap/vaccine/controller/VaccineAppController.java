package com.tap.vaccine.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import com.tap.vaccine.service.RegisterService;

@Controller
public class VaccineAppController {
	
	private  RegisterService registerService;
		
	@Autowired
	public VaccineAppController(RegisterService registerService) {
		
		this.registerService = registerService;
	}
	
	public VaccineAppController() {
		System.out.println("VaccineAppController invoked");
	}
	@RequestMapping(value="/getRegisterPage")
	public String getRegisterPage() {
	    return "/WEB-INF/register.jsp";
	}

	
	@RequestMapping(value = "/getRegisterData", method = RequestMethod.POST)
	public String getRegisterData(@RequestParam String userName,
                                 @RequestParam String password,
                                 @RequestParam String confirmPassword,
                                 @RequestParam String email,
                                 @RequestParam String mobileNumber,
                                 @RequestParam String gender,
                                 @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") String dateOfBirth, Model model) {
		
		System.out.println(" getRegisterData Invoked");
		
		if(!registerService.validateUserName(userName)){
			
			model.addAttribute("userName","USERNAME SHOULD CONTAINS ALPHABETS & NUMBERS ONLY");
		}
		if(!registerService.validatePassword(password)){
			
			model.addAttribute("password1", "PASSWORD SHOULD BE MINIMUM 8 CHARECTERS");
			model.addAttribute("password2", "PASSWORD SHOULD CONTAIN ATLEAST ONE UPPER CHARECTER");
			model.addAttribute("password3", "PASSWORD SHOULD CONTAIN ATLEAST ONE LOWER CHARECTER ");
			model.addAttribute("password4", "PASSWORD SHOULD CONTAIN ATLEAST ONE SPECIAL CHARECTER");
			model.addAttribute("password5","PASSWORD SHOULD CONTAIN ATLEAST ONE NUMBER");	
		}
		
		if(!registerService.validateConfirmPassword(confirmPassword)) {
			
			model.addAttribute("response","PASSWORD NOT MATCH");
		}
		
		if(!registerService.validateEmail(email)) {
			model.addAttribute("email","PLEASE GIVE VALID EMAIL");
		}
		if(!registerService.validateMobileNumber(mobileNumber)) {
			model.addAttribute("mobileNumber","PLEASE ENTER VALID MOBILENUMBER");
		}
		if(!registerService.validateGender(gender)) {
			model.addAttribute("gender"+ "","SELECT GENDER");
		}
		
		
		if (!registerService.validateDateOfBirth(dateOfBirth)) {
		    model.addAttribute("dateOfBirth", "SELECT DATEOFBIRTH");
		}

		if(registerService.validateRegisterData(userName, password, confirmPassword, email, mobileNumber, gender, dateOfBirth)) {
			
			if(registerService.saveRegisterData(userName, password, email, mobileNumber, gender, dateOfBirth)) {
			    model.addAttribute("response","Data Saved Successfully");
			    return "redirect:/index.jsp";
			    
			} else {
			    model.addAttribute("no","Data doesn't exist");
			}
		}
		else {
			model.addAttribute("no","FAILED ....TRY AGAIN...");
			
		}
		
		return "/WEB-INF/register.jsp";
		
	}     
}