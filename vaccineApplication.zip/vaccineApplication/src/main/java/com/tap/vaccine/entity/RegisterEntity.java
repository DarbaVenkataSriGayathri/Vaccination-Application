package com.tap.vaccine.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="vaccine_table")
public class RegisterEntity {
	@Id
    @Column(name = "REGISTER_ID")
    int registerId;

    @Column(name = "USER_NAME")
    String userName;

    @Column(name = "PASSWORD")
    String password;

    @Column(name = "EMAIL", unique = true)
    String email;

    @Column(name = "MOBILE_NUMBER")
    String mobileNumber;

    @Column(name = "GENDER")
    String gender;

    @Column(name = "DATE_OF_BIRTH")
    String dateOfBirth;
    
    @Column(name = "LOGIN_ATTEMPT")
    int loginAttempt;
    
    public RegisterEntity() {
    	System.out.println("RegisterEntity is Invoked.. This is Default Contructor");
	}

	

	public RegisterEntity(int registerId, String userName, String password, String email, String mobileNumber,
			String gender, String dateOfBirth, int loginAttempt) {
		super();
		this.registerId = registerId;
		this.userName = userName;
		this.password = password;
		this.email = email;
		this.mobileNumber = mobileNumber;
		this.gender = gender;
		this.dateOfBirth = dateOfBirth;
		this.loginAttempt = loginAttempt;
	}



	public RegisterEntity(String userName, String password, String email, String mobileNumber, String gender,
			String dateOfBirth) {
		super();
		this.userName = userName;
		this.password = password;
		this.email = email;
		this.mobileNumber = mobileNumber;
		this.gender = gender;
		this.dateOfBirth = dateOfBirth;
	}
	
	
	public RegisterEntity(String password, String email) {
		super();
		this.password = password;
		this.email = email;
	}

	public int getRegisterId() {
		return registerId;
	}

	public void setRegisterId(int registerId) {
		this.registerId = registerId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}



	public int getLoginAttempt() {
		return loginAttempt;
	}



	public void setLoginAttempt(int loginAttempt) {
		this.loginAttempt = loginAttempt;
	}
	
    
}